from flask import Flask

app = Flask("Penguin Api")